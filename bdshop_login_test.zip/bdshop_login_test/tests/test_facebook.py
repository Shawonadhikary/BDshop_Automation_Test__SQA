from pages.fb_page import FacebookPage
from pages.login_page import BdshopLoginPage

def test_facebook_link(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    fb = FacebookPage(page)
    fb.go_to_facebook()