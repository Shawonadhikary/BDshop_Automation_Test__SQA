from pages.login_page import BdshopLoginPage
from pages.wishlist_page import WishlistPage

def test_view_wishlist(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    wishlist = WishlistPage(page)
    wishlist.go_to_wishlist()