from pages.login_page import BdshopLoginPage
from pages.view_more_page import ViewMorePage

def test_view_more_products(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    view_more = ViewMorePage(page)
    view_more.click_view_more()