from pages.login_page import BdshopLoginPage
from pages.view_cart import ViewCartPage

def test_view_cart(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    view_cart = ViewCartPage(page)
    view_cart.view_cart()


#pytest tests/test_view_cart.py -s
