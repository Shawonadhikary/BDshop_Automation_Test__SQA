from pages.login_page import BdshopLoginPage
from pages.proceed_to_checkout import CheckoutPage

def test_checkout(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    checkout = CheckoutPage(page)
    checkout.proceed_to_checkout()

#pytest tests/test_checkout.py -s