from pages.login_page import BdshopLoginPage
from pages.change_password_page import ChangePasswordPage

def test_navigate_to_change_password(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    change_pass = ChangePasswordPage(page)
    change_pass.go_to_change_password()