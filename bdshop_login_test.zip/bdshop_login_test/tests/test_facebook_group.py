from pages.fb_group_page import FacebookGroupPage
from pages.login_page import BdshopLoginPage

def test_facebook_group_link(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    fb_group = FacebookGroupPage(page)
    fb_group.go_to_facebook_group()