from pages.login_page import BdshopLoginPage
from pages.home_page import HomePage

def test_homepage_navigation(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    home = HomePage(page)
    home.go_home()

    assert "https://www.bdshop.com/" in page.url

#pytest tests/test_homepage.py -s
