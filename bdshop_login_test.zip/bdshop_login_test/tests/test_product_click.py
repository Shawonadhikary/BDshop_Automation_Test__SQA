from pages.product_click import ProductClickPage

def test_product_click(page):
    product = ProductClickPage(page)
    product.navigate()
    product.click_first_product()
    assert product.is_product_page_loaded()


    #pytest tests/test_product_click.py -s
