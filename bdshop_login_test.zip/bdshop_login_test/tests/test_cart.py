from pages.login_page import BdshopLoginPage
from pages.cart_page import CartPage

def test_go_to_cart(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    cart = CartPage(page)
    cart.go_to_cart()

    assert "checkout/cart" in page.url


#pytest tests/test_go_to_cart.py -s 