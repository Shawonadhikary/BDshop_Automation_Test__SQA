from pages.deals_page import DealsPage
from pages.login_page import BdshopLoginPage

def test_view_all_deals(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    deals = DealsPage(page)
    deals.view_all_deals()