from pages.login_page import BdshopLoginPage
from pages.my_orders_page import MyOrdersPage

def test_navigate_to_my_orders(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    my_orders = MyOrdersPage(page)
    my_orders.go_to_my_orders()