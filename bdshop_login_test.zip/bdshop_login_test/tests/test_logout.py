from pages.login_page import BdshopLoginPage
from pages.logout_page import LogoutPage

def test_logout(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    logout = LogoutPage(page)
    logout.logout()


#pytest tests/test_logout.py -s