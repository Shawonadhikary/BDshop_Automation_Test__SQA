from pages.login_page import BdshopLoginPage
from pages.payment_page import PaymentPage

def test_bkash_payment(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    payment = PaymentPage(page)
    payment.go_to_pay_now()
    payment.choose_bkash_payment()

    # Optional: add validation here (like checking URL or confirmation text)
    page.wait_for_timeout(3000)
