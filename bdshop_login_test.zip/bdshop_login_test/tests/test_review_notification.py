from pages.login_page import BdshopLoginPage
from pages.review_notification_page import ReviewNotificationPage

def test_review_notification(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    review = ReviewNotificationPage(page)
    review.go_to_review_notification()