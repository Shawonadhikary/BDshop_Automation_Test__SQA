from pages.free_delivery_page import FreeDeliveryPage
from pages.login_page import BdshopLoginPage

def test_navigate_to_free_delivery(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    free_delivery = FreeDeliveryPage(page)
    free_delivery.go_to_free_delivery()