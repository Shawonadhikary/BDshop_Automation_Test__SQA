from pages.login_page import BdshopLoginPage
from pages.visa_payment_page import VisaPaymentPage

def test_visa_mastercard_payment(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    visa = VisaPaymentPage(page)
    visa.go_to_payment_page()
    visa.select_visa_payment()