from pages.login_page import BdshopLoginPage
from pages.cart_page import CartPage
from pages.clear_cart import ClearCartPage

def test_clear_cart(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    cart = CartPage(page)
    cart.go_to_cart()

    clear = ClearCartPage(page)
    clear.clear_cart()

    page.wait_for_timeout(3000)


#pytest tests/test_clear_cart.py -s
