from pages.login_page import BdshopLoginPage
from pages.search_page import SearchPage

def test_product_search(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    search = SearchPage(page)
    search.search_product("microphone")
