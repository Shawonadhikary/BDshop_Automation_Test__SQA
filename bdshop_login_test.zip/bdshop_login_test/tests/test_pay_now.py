from pages.login_page import BdshopLoginPage
from pages.pay_now_page import PayNowPage

def test_pay_now(page):
    login = BdshopLoginPage(page)
    login.navigate()
    login.login("shounadhikary725@gmail.com", "exMPn@k6SAE$Fdk")

    pay = PayNowPage(page)
    pay.go_to_payment()
