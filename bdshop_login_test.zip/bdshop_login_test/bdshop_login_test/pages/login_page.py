class BdshopLoginPage:
    def __init__(self, page):
        self.page = page
        self.email_input = "#email"
        self.password_input = "#pass"
        self.login_button = "button:has-text('Log In')"

    def navigate(self):
        self.page.goto("https://www.bdshop.com/customer/account/login/")

    def login(self, email, password):
        self.page.fill(self.email_input, email)
        self.page.fill(self.password_input, password)
        self.page.click(self.login_button)
        self.page.wait_for_timeout(3000)