class HomePage:
    def __init__(self, page):
        self.page = page
        self.logo_link = "a.logo"  # relaxed selector

    def go_home(self):
        print("🔍 Checking if logo is visible...")
        if self.page.is_visible(self.logo_link):
            print("✅ Logo found. Clicking to go home...")
            self.page.click(self.logo_link)
            self.page.wait_for_load_state("networkidle")
            self.page.wait_for_timeout(3000)
        else:
            print("❌ Logo not found. Skipping homepage click.")
