class ReviewNotificationPage:
    def __init__(self, page):
        self.page = page
        self.edit_review_link = "a[href*='aw_advanced_reviews/customer']"

    def go_to_review_notification(self):
        self.page.wait_for_selector(self.edit_review_link, timeout=10000)
        self.page.click(self.edit_review_link)