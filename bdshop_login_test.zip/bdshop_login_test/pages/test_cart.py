class CartPage:
    def __init__(self, page):
        self.page = page
        self.cart_icon = "span.counter.qty"

    def go_to_cart(self):
        self.page.wait_for_selector(self.cart_icon, timeout=10000)
        self.page.click(self.cart_icon)
        self.page.wait_for_timeout(3000)
