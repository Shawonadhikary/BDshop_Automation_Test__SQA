class CartPage:
    def __init__(self, page):
        self.page = page
        self.cart_icon = "a.action.showcart[href*='/checkout/cart/']"

    def go_to_cart(self):
        self.page.wait_for_selector(self.cart_icon, timeout=10000)
        self.page.click(self.cart_icon)
