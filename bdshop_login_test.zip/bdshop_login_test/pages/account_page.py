from playwright.sync_api import Page, expect

class AccountPage:
    def __init__(self, page: Page):
        self.page = page
        self.account_dropdown = page.locator("div.customer-name.acc-btn")
        self.my_account_link = page.locator("text=My Account")  
        
    def open_account_menu(self):
        expect(self.account_dropdown).to_be_visible()
        self.account_dropdown.click()

    def go_to_my_account(self):
        self.open_account_menu()
        expect(self.my_account_link).to_be_visible()
        self.my_account_link.click()
        self.page.wait_for_load_state("networkidle")

    def is_on_account_page(self):
        return "customer/account" in self.page.url
