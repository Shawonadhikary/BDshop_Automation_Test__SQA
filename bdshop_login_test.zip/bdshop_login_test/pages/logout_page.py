class LogoutPage:
    def __init__(self, page):
        self.page = page
        self.profile_button = ".customer-name.acc-btn"
        self.logout_link = "a[href*='/customer/account/logout/']"

    def logout(self):
        self.page.wait_for_selector(self.profile_button, timeout=10000)
        self.page.click(self.profile_button)

        self.page.wait_for_selector(self.logout_link, timeout=10000)
        self.page.click(self.logout_link)
