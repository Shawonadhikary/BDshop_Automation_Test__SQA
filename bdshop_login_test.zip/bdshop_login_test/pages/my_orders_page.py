class MyOrdersPage:
    def __init__(self, page):
        self.page = page
        self.my_orders_link = "a[href='https://www.bdshop.com/sales/order/history/']"

    def go_to_my_orders(self):
        self.page.wait_for_selector(self.my_orders_link, timeout=10000)
        self.page.click(self.my_orders_link)