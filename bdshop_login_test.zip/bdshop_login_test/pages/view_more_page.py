class ViewMorePage:
    def __init__(self, page):
        self.page = page
        self.view_more_button = "button:text('View More')"

    def click_view_more(self):
        self.page.wait_for_selector(self.view_more_button, timeout=10000)
        self.page.click(self.view_more_button)