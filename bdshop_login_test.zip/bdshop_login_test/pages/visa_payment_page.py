class VisaPaymentPage:
    def __init__(self, page):
        self.page = page
        self.pay_now_link = "a[href*='pay.bdshop.com']"
        self.visa_button_text = "Visa/Master Card Payment"

    def go_to_payment_page(self):
        self.page.wait_for_selector(self.pay_now_link, timeout=10000)
        self.page.click(self.pay_now_link)

    def select_visa_payment(self):
       
        self.page.wait_for_load_state("load")
        self.page.wait_for_timeout(3000)  

        
        self.page.click("text='Visa/Master Card Payment'")