from playwright.sync_api import Page, expect

class ProductClickPage:
    def __init__(self, page: Page):
        self.page = page
        self.first_product_link = page.locator("a.product-item-link").first

    def navigate(self):
        self.page.goto("https://www.bdshop.com/")
        self.page.wait_for_load_state("domcontentloaded")

    def click_first_product(self):
        self.page.mouse.wheel(0, 1000)  
        expect(self.first_product_link).to_be_visible()
        self.first_product_link.click()
        self.page.wait_for_load_state("networkidle")

    def is_product_page_loaded(self):
        return "/product" in self.page.url or "/item" in self.page.url or "bdshop.com" in self.page.url


#pytest tests/test_product_click.py -s