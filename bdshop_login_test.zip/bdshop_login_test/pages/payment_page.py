class PaymentPage:
    def __init__(self, page):
        self.page = page
        self.pay_now_button = "a[href*='pay.bdshop.com']"
        self.bkash_button = "span.elementor-button-text:text('Bkash Online Payment')"

    def go_to_pay_now(self):
        self.page.wait_for_selector(self.pay_now_button)
        self.page.click(self.pay_now_button)

    def choose_bkash_payment(self):
        self.page.wait_for_selector(self.bkash_button, timeout=10000)
        self.page.click(self.bkash_button)
