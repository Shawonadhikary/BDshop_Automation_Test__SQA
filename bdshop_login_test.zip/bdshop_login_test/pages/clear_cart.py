class ClearCartPage:
    def __init__(self, page):
        self.page = page
        self.clear_cart_button = "#empty_cart_button"

    def clear_cart(self):
        self.page.wait_for_selector(self.clear_cart_button, timeout=10000)
        self.page.click(self.clear_cart_button)
       


#pytest tests/test_clear_cart.py -s