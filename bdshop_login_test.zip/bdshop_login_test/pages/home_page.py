class HomePage:
    def __init__(self, page):
        self.page = page
        self.logo_link = "a.logo[href='https://www.bdshop.com/']"

    def go_home(self):
        self.page.wait_for_selector(self.logo_link, timeout=10000)
        self.page.click(self.logo_link)


        #pytest tests/test_homepage.py -s
