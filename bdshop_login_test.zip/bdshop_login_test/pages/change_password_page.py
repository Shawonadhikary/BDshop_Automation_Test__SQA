class ChangePasswordPage:
    def __init__(self, page):
        self.page = page
        self.change_password_link = "a.action.change-password"

    def go_to_change_password(self):
        self.page.wait_for_selector(self.change_password_link, timeout=10000)
        self.page.click(self.change_password_link)