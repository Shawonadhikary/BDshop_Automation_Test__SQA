class BdshopLoginPage:
    def __init__(self, page):
        self.page = page
        self.email_input = "input[name='login[username]']"
        self.password_input = "input[name='login[password]']"
        self.login_button = "button:has-text('Log In')"

    def navigate(self):
        self.page.goto("https://www.bdshop.com/customer/account/login/")

    def login(self, email, password):
        self.page.wait_for_selector(self.email_input)
        self.page.fill(self.email_input, email)
        self.page.fill(self.password_input, password)
        self.page.click(self.login_button)
        self.page.wait_for_timeout(3000)
