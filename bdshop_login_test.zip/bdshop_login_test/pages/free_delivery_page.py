class FreeDeliveryPage:
    def __init__(self, page):
        self.page = page
        self.free_delivery_link = "a[href='https://www.bdshop.com/free-delivery']"

    def go_to_free_delivery(self):
        self.page.wait_for_selector(self.free_delivery_link, timeout=10000)
        self.page.click(self.free_delivery_link)