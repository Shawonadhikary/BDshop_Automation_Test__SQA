class FacebookPage:
    def __init__(self, page):
        self.page = page
        self.fb_link = "a[href*='https://www.facebook.com/BDSHOPS']"

    def go_to_facebook(self):
        self.page.wait_for_selector(self.fb_link, timeout=10000)
        self.page.click(self.fb_link)