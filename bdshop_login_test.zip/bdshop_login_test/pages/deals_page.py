class DealsPage:
    def __init__(self, page):
        self.page = page
        self.view_all_button = "a[href='/deals-of-the-day']"

    def view_all_deals(self):
        self.page.wait_for_selector(self.view_all_button, timeout=10000)
        self.page.click(self.view_all_button)