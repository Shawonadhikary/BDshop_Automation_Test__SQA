class PayNowPage:
    def __init__(self, page):
        self.page = page
        self.pay_now_link = "a[href='https://pay.bdshop.com/']"

    def go_to_payment(self):
        self.page.wait_for_selector(self.pay_now_link, timeout=10000)
        self.page.click(self.pay_now_link)
