class FacebookGroupPage:
    def __init__(self, page):
        self.page = page
        self.fb_group_link = "a[href*='https://www.facebook.com/groups/BDShopClub']"

    def go_to_facebook_group(self):
        self.page.wait_for_selector(self.fb_group_link, timeout=10000)
        self.page.click(self.fb_group_link)