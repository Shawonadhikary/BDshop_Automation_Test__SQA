class WishlistPage:
    def __init__(self, page):
        self.page = page
        self.wishlist_link = "a[href*='/wishlist']"

    def go_to_wishlist(self):
        self.page.wait_for_selector(self.wishlist_link, timeout=10000)
        self.page.click(self.wishlist_link)