class CheckoutPage:
    def __init__(self, page):
        self.page = page
        self.checkout_btn = "span:has-text('Proceed to Checkout')"

    def proceed_to_checkout(self):
        self.page.wait_for_selector(self.checkout_btn, timeout=10000)
        self.page.click(self.checkout_btn)
        self.page.wait_for_timeout(3000)


#pytest tests/test_checkout.py -s