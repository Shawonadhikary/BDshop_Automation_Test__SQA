class SearchPage:
    def __init__(self, page):
        self.page = page
        self.search_input = "input#search"
        self.search_button = "button[title='Search']"

    def search_product(self, query):
        print(f" Searching for: {query}")
        self.page.wait_for_selector(self.search_input, timeout=10000)
        self.page.fill(self.search_input, query)
        self.page.click(self.search_button)
        self.page.wait_for_load_state("networkidle")
        self.page.wait_for_timeout(3000)
